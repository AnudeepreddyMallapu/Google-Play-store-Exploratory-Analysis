

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
import re
from IPython.display import display
pd.options.display.max_rows=None
from scipy import stats
from statsmodels.formula.api import ols 
from IPython.display import display, Markdown
%matplotlib inline
```


```python
playstore=pd.read_csv(r"C:\Users\andee\googleplaystore.csv")
```


```python
#Checking out the info, datatype, number of rows, columns
playstore.info()
playstore.head()

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10841 entries, 0 to 10840
    Data columns (total 13 columns):
    App               10841 non-null object
    Category          10841 non-null object
    Rating            9367 non-null float64
    Reviews           10841 non-null object
    Size              10841 non-null object
    Installs          10841 non-null object
    Type              10840 non-null object
    Price             10841 non-null object
    Content Rating    10840 non-null object
    Genres            10841 non-null object
    Last Updated      10841 non-null object
    Current Ver       10833 non-null object
    Android Ver       10838 non-null object
    dtypes: float64(1), object(12)
    memory usage: 1.1+ MB
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>App</th>
      <th>Category</th>
      <th>Rating</th>
      <th>Reviews</th>
      <th>Size</th>
      <th>Installs</th>
      <th>Type</th>
      <th>Price</th>
      <th>Content Rating</th>
      <th>Genres</th>
      <th>Last Updated</th>
      <th>Current Ver</th>
      <th>Android Ver</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Photo Editor &amp; Candy Camera &amp; Grid &amp; ScrapBook</td>
      <td>ART_AND_DESIGN</td>
      <td>4.1</td>
      <td>159</td>
      <td>19M</td>
      <td>10,000+</td>
      <td>Free</td>
      <td>0</td>
      <td>Everyone</td>
      <td>Art &amp; Design</td>
      <td>January 7, 2018</td>
      <td>1.0.0</td>
      <td>4.0.3 and up</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Coloring book moana</td>
      <td>ART_AND_DESIGN</td>
      <td>3.9</td>
      <td>967</td>
      <td>14M</td>
      <td>500,000+</td>
      <td>Free</td>
      <td>0</td>
      <td>Everyone</td>
      <td>Art &amp; Design;Pretend Play</td>
      <td>January 15, 2018</td>
      <td>2.0.0</td>
      <td>4.0.3 and up</td>
    </tr>
    <tr>
      <th>2</th>
      <td>U Launcher Lite – FREE Live Cool Themes, Hide ...</td>
      <td>ART_AND_DESIGN</td>
      <td>4.7</td>
      <td>87510</td>
      <td>8.7M</td>
      <td>5,000,000+</td>
      <td>Free</td>
      <td>0</td>
      <td>Everyone</td>
      <td>Art &amp; Design</td>
      <td>August 1, 2018</td>
      <td>1.2.4</td>
      <td>4.0.3 and up</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Sketch - Draw &amp; Paint</td>
      <td>ART_AND_DESIGN</td>
      <td>4.5</td>
      <td>215644</td>
      <td>25M</td>
      <td>50,000,000+</td>
      <td>Free</td>
      <td>0</td>
      <td>Teen</td>
      <td>Art &amp; Design</td>
      <td>June 8, 2018</td>
      <td>Varies with device</td>
      <td>4.2 and up</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Pixel Draw - Number Art Coloring Book</td>
      <td>ART_AND_DESIGN</td>
      <td>4.3</td>
      <td>967</td>
      <td>2.8M</td>
      <td>100,000+</td>
      <td>Free</td>
      <td>0</td>
      <td>Everyone</td>
      <td>Art &amp; Design;Creativity</td>
      <td>June 20, 2018</td>
      <td>1.1</td>
      <td>4.4 and up</td>
    </tr>
  </tbody>
</table>
</div>




```python
playstore.drop(index=10472,inplace=True)

```


```python
def change_size(size):
    kb= size.str.endswith("k")
    MB=  size.str.endswith("M")
    other= ~(kb|MB)
    size.loc[kb]= size[kb].str.replace("k","").astype("float")/1024
    size.loc[MB]= size[MB].str.replace("M","").astype("float")
    size.loc[other] = float(0.0)
change_size(playstore.Size)
playstore.columns= [x.replace(" ","_") for x in  playstore.columns]
playstore.Installs= np.log(playstore.Installs.str.replace("[+,]","").astype("int64")+1)
playstore.Reviews= np.log(playstore.Reviews.astype("int")+1)
playstore.Price= playstore.Price.str.replace("[$,]","").astype("float")
playstore.Size=playstore.Size.astype("float")
#playstore.Type= pd.get_dummies(playstore.Type,drop_first=True)
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    <ipython-input-72-d54071989fea> in <module>
          6     size.loc[MB]= size[MB].str.replace("M","").astype("float")
          7     size.loc[other] = float(0.0)
    ----> 8 change_size(playstore.Size)
          9 playstore.columns= [x.replace(" ","_") for x in  playstore.columns]
         10 playstore.Installs= np.log(playstore.Installs.str.replace("[+,]","").astype("int64")+1)
    

    <ipython-input-72-d54071989fea> in change_size(size)
          1 def change_size(size):
    ----> 2     kb= size.str.endswith("k")
          3     MB=  size.str.endswith("M")
          4     other= ~(kb|MB)
          5     size.loc[kb]= size[kb].str.replace("k","").astype("float")/1024
    

    ~\Anaconda3\lib\site-packages\pandas\core\generic.py in __getattr__(self, name)
       4370         if (name in self._internal_names_set or name in self._metadata or
       4371                 name in self._accessors):
    -> 4372             return object.__getattribute__(self, name)
       4373         else:
       4374             if self._info_axis._can_hold_identifiers_and_holds_name(name):
    

    ~\Anaconda3\lib\site-packages\pandas\core\accessor.py in __get__(self, obj, cls)
        131             # we're accessing the attribute of the class, i.e., Dataset.geo
        132             return self._accessor
    --> 133         accessor_obj = self._accessor(obj)
        134         # Replace the property with the accessor object. Inspired by:
        135         # http://www.pydanny.com/cached-property.html
    

    ~\Anaconda3\lib\site-packages\pandas\core\strings.py in __init__(self, data)
       1893 
       1894     def __init__(self, data):
    -> 1895         self._validate(data)
       1896         self._is_categorical = is_categorical_dtype(data)
       1897 
    

    ~\Anaconda3\lib\site-packages\pandas\core\strings.py in _validate(data)
       1915             # (instead of test for object dtype), but that isn't practical for
       1916             # performance reasons until we have a str dtype (GH 9343)
    -> 1917             raise AttributeError("Can only use .str accessor with string "
       1918                                  "values, which use np.object_ dtype in "
       1919                                  "pandas")
    

    AttributeError: Can only use .str accessor with string values, which use np.object_ dtype in pandas



```python
playstore.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 10829 entries, 0 to 10840
    Data columns (total 13 columns):
    App               10829 non-null object
    Category          10829 non-null object
    Rating            10829 non-null float64
    Reviews           10829 non-null float64
    Size              10829 non-null float64
    Installs          10829 non-null float64
    Type              10829 non-null object
    Price             10829 non-null float64
    Content_Rating    10829 non-null object
    Genres            10829 non-null object
    Last_Updated      10829 non-null object
    Current_Ver       10829 non-null object
    Android_Ver       10829 non-null object
    dtypes: float64(5), object(8)
    memory usage: 1.5+ MB
    


```python
#Dealing with Null Values
```


```python
total = playstore.isnull().sum().sort_values(ascending=False)
percent = (playstore.isnull().sum()/playstore.isnull().count()).sort_values(ascending=False)
missing_data = pd.concat([total, percent], axis=1, keys=['Total', 'Percent'])
display(missing_data.head(6))
print("Before Cleaning")
display(playstore.shape)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Total</th>
      <th>Percent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Android_Ver</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Current_Ver</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Last_Updated</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Genres</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Content_Rating</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Price</th>
      <td>0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>


    Before Cleaning
    


    (10829, 13)



```python
playstore.Rating.fillna(method='ffill',inplace=True)
playstore.dropna(how ='any', inplace = True)
print("After Cleaning")
playstore.shape
```

    After Cleaning
    




    (10829, 13)




```python
sns.pairplot(playstore,kind="scatter",hue='Type')
```

    C:\Users\andee\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    C:\Users\andee\Anaconda3\lib\site-packages\statsmodels\nonparametric\kde.py:488: RuntimeWarning: invalid value encountered in true_divide
      binned = fast_linbin(X, a, b, gridsize) / (delta * nobs)
    C:\Users\andee\Anaconda3\lib\site-packages\statsmodels\nonparametric\kdetools.py:34: RuntimeWarning: invalid value encountered in double_scalars
      FAC1 = 2*(np.pi*bw/RANGE)**2
    C:\Users\andee\Anaconda3\lib\site-packages\numpy\core\fromnumeric.py:83: RuntimeWarning: invalid value encountered in reduce
      return ufunc.reduce(obj, axis, dtype, out, **passkwargs)
    




    <seaborn.axisgrid.PairGrid at 0x1f5a4c02f98>




![png](output_10_2.png)


1- Most of the rating are on or above 4.

2- Rating and reiveiws have a positive correlation

3- Free apps reviews are more spread then paid apps revies.

4- Reviews and Installs have a strong correlation.

5- Instalation is almost normaly destributed for both paid and free app

6- most of the app size is below 50 MB



```python
playstore.Category.value_counts().plot(kind='bar',figsize=(18,6))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f5a4bc1550>




![png](output_12_1.png)


By category destribution we can see that most of the app are from top 3 category.


```python
playstore.groupby("Type")["Type"].value_counts().plot(kind='pie',autopct='%1.1f%%' );
```


![png](output_14_0.png)


Only about 7% app are paid App.


```python
sns.catplot(x="Type",y="Installs",kind='box',data=playstore,  height=4, aspect=2/1);
```


![png](output_16_0.png)


Here I found that Free apps are way more downloaded than paid apps.


```python
sns.catplot(x="Type",y="Rating",kind='box',data=playstore,  height=4, aspect=2/1);
```


![png](output_18_0.png)


Here Paid apps have better rating than free apps.

Q.Are paid have significantly better rating than free apps?


```python
#null Hypothisis- avg rating are same for paid and free app
model_name = ols('Rating ~ C(Type)', data=playstore).fit()
model_name.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>Rating</td>      <th>  R-squared:         </th> <td>   0.001</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.001</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   6.417</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 25 Feb 2019</td> <th>  Prob (F-statistic):</th>  <td>0.0113</td>  
</tr>
<tr>
  <th>Time:</th>                 <td>11:35:08</td>     <th>  Log-Likelihood:    </th> <td> -8816.4</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td> 10829</td>      <th>  AIC:               </th> <td>1.764e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td> 10827</td>      <th>  BIC:               </th> <td>1.765e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     1</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
         <td></td>            <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>       <td>    4.1881</td> <td>    0.005</td> <td>  767.943</td> <td> 0.000</td> <td>    4.177</td> <td>    4.199</td>
</tr>
<tr>
  <th>C(Type)[T.Paid]</th> <td>    0.0509</td> <td>    0.020</td> <td>    2.533</td> <td> 0.011</td> <td>    0.012</td> <td>    0.090</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>4330.970</td> <th>  Durbin-Watson:     </th> <td>   1.355</td> 
</tr>
<tr>
  <th>Prob(Omnibus):</th>  <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>22634.907</td>
</tr>
<tr>
  <th>Skew:</th>           <td>-1.872</td>  <th>  Prob(JB):          </th> <td>    0.00</td> 
</tr>
<tr>
  <th>Kurtosis:</th>       <td> 9.012</td>  <th>  Cond. No.          </th> <td>    3.85</td> 
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



Here Paid app have significantly higher rating than free app.


```python
sns.catplot(x="Type",y="Size",kind='box',data=playstore, height=4, aspect=2/1);

```


![png](output_23_0.png)


Size are almost same for the paid and free app.

### Price of the apps


```python
sns.catplot("Price","Category",data=playstore[playstore.Price>0],height=10,aspect=1.5,hue="Content_Rating",s=10,alpha=.3);
```


![png](output_26_0.png)


Lets look into high price app




```python
playstore[playstore.Price>200][["Category","App","Price"]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>App</th>
      <th>Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4197</th>
      <td>FAMILY</td>
      <td>most expensive app (H)</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>4362</th>
      <td>LIFESTYLE</td>
      <td>💎 I'm rich</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>4367</th>
      <td>LIFESTYLE</td>
      <td>I'm Rich - Trump Edition</td>
      <td>400.00</td>
    </tr>
    <tr>
      <th>5351</th>
      <td>LIFESTYLE</td>
      <td>I am rich</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5354</th>
      <td>FAMILY</td>
      <td>I am Rich Plus</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5355</th>
      <td>LIFESTYLE</td>
      <td>I am rich VIP</td>
      <td>299.99</td>
    </tr>
    <tr>
      <th>5356</th>
      <td>FINANCE</td>
      <td>I Am Rich Premium</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5357</th>
      <td>LIFESTYLE</td>
      <td>I am extremely Rich</td>
      <td>379.99</td>
    </tr>
    <tr>
      <th>5358</th>
      <td>FINANCE</td>
      <td>I am Rich!</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5359</th>
      <td>FINANCE</td>
      <td>I am rich(premium)</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5362</th>
      <td>FAMILY</td>
      <td>I Am Rich Pro</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5364</th>
      <td>FINANCE</td>
      <td>I am rich (Most expensive app)</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5366</th>
      <td>FAMILY</td>
      <td>I Am Rich</td>
      <td>389.99</td>
    </tr>
    <tr>
      <th>5369</th>
      <td>FINANCE</td>
      <td>I am Rich</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>5373</th>
      <td>FINANCE</td>
      <td>I AM RICH PRO PLUS</td>
      <td>399.99</td>
    </tr>
    <tr>
      <th>9917</th>
      <td>FINANCE</td>
      <td>Eu Sou Rico</td>
      <td>394.99</td>
    </tr>
    <tr>
      <th>9934</th>
      <td>LIFESTYLE</td>
      <td>I'm Rich/Eu sou Rico/أنا غني/我很有錢</td>
      <td>399.99</td>
    </tr>
  </tbody>
</table>
</div>



They all look junk app, lets remove them and plot the graph again




```python
sns.catplot("Price","Category",data=playstore[playstore.Price>0],height=10,aspect=1.5,hue="Content_Rating",s=10,alpha=.3)
```




    <seaborn.axisgrid.FacetGrid at 0x1f5a6f7c3c8>




![png](output_30_1.png)


Here we found

1-Most of the app are priced well below $50.

2-Most of the paid are from family, Medical and games category.

### Paid apps Content Rating



```python
playstore[playstore.Price>0].groupby("Content_Rating")["App"].count().plot(kind='bar')

```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f5a8912e10>




![png](output_33_1.png)


Most of the paid are for everyone's use, With some of the app focused on teen.

## EDA for category and Genres
### Size of app


```python
sns.catplot("Size","Category",data=playstore,height=10,aspect=2/1,c=1/1000,s=10,alpha=0.2,hue="Content_Rating")
```




    <seaborn.axisgrid.FacetGrid at 0x1f5a88e2b38>




![png](output_36_1.png)


Most of the large size app are form Family and Game category


### Rating by Category



```python
sns.catplot(x="Category",y="Rating",kind='box',data=playstore, height=8, aspect=2/1);
plt.xticks(rotation=90);
```


![png](output_39_0.png)


Average rating accross the category is around 4.2. But are the same across the category.




```python
model_name = ols('Rating ~ C(Category)', data=playstore).fit()

```


```python
model_name.summary()

```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>Rating</td>      <th>  R-squared:         </th> <td>   0.025</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.022</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   8.531</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Mon, 25 Feb 2019</td> <th>  Prob (F-statistic):</th> <td>1.85e-39</td> 
</tr>
<tr>
  <th>Time:</th>                 <td>11:41:11</td>     <th>  Log-Likelihood:    </th> <td> -8684.4</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td> 10829</td>      <th>  AIC:               </th> <td>1.743e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td> 10796</td>      <th>  BIC:               </th> <td>1.768e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>    32</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
                   <td></td>                     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>                          <td>    4.4016</td> <td>    0.068</td> <td>   65.161</td> <td> 0.000</td> <td>    4.269</td> <td>    4.534</td>
</tr>
<tr>
  <th>C(Category)[T.AUTO_AND_VEHICLES]</th>   <td>   -0.2039</td> <td>    0.089</td> <td>   -2.280</td> <td> 0.023</td> <td>   -0.379</td> <td>   -0.029</td>
</tr>
<tr>
  <th>C(Category)[T.BEAUTY]</th>              <td>   -0.1393</td> <td>    0.100</td> <td>   -1.388</td> <td> 0.165</td> <td>   -0.336</td> <td>    0.057</td>
</tr>
<tr>
  <th>C(Category)[T.BOOKS_AND_REFERENCE]</th> <td>   -0.0985</td> <td>    0.076</td> <td>   -1.290</td> <td> 0.197</td> <td>   -0.248</td> <td>    0.051</td>
</tr>
<tr>
  <th>C(Category)[T.BUSINESS]</th>            <td>   -0.2674</td> <td>    0.072</td> <td>   -3.709</td> <td> 0.000</td> <td>   -0.409</td> <td>   -0.126</td>
</tr>
<tr>
  <th>C(Category)[T.COMICS]</th>              <td>   -0.2349</td> <td>    0.097</td> <td>   -2.419</td> <td> 0.016</td> <td>   -0.425</td> <td>   -0.045</td>
</tr>
<tr>
  <th>C(Category)[T.COMMUNICATION]</th>       <td>   -0.2354</td> <td>    0.073</td> <td>   -3.228</td> <td> 0.001</td> <td>   -0.378</td> <td>   -0.092</td>
</tr>
<tr>
  <th>C(Category)[T.DATING]</th>              <td>   -0.4870</td> <td>    0.076</td> <td>   -6.389</td> <td> 0.000</td> <td>   -0.636</td> <td>   -0.338</td>
</tr>
<tr>
  <th>C(Category)[T.EDUCATION]</th>           <td>   -0.0105</td> <td>    0.080</td> <td>   -0.131</td> <td> 0.895</td> <td>   -0.168</td> <td>    0.147</td>
</tr>
<tr>
  <th>C(Category)[T.ENTERTAINMENT]</th>       <td>   -0.2754</td> <td>    0.081</td> <td>   -3.410</td> <td> 0.001</td> <td>   -0.434</td> <td>   -0.117</td>
</tr>
<tr>
  <th>C(Category)[T.EVENTS]</th>              <td>   -0.0016</td> <td>    0.096</td> <td>   -0.016</td> <td> 0.987</td> <td>   -0.189</td> <td>    0.186</td>
</tr>
<tr>
  <th>C(Category)[T.FAMILY]</th>              <td>   -0.2017</td> <td>    0.069</td> <td>   -2.938</td> <td> 0.003</td> <td>   -0.336</td> <td>   -0.067</td>
</tr>
<tr>
  <th>C(Category)[T.FINANCE]</th>             <td>   -0.2393</td> <td>    0.073</td> <td>   -3.268</td> <td> 0.001</td> <td>   -0.383</td> <td>   -0.096</td>
</tr>
<tr>
  <th>C(Category)[T.FOOD_AND_DRINK]</th>      <td>   -0.2527</td> <td>    0.083</td> <td>   -3.051</td> <td> 0.002</td> <td>   -0.415</td> <td>   -0.090</td>
</tr>
<tr>
  <th>C(Category)[T.GAME]</th>                <td>   -0.1194</td> <td>    0.069</td> <td>   -1.720</td> <td> 0.085</td> <td>   -0.255</td> <td>    0.017</td>
</tr>
<tr>
  <th>C(Category)[T.HEALTH_AND_FITNESS]</th>  <td>   -0.1426</td> <td>    0.074</td> <td>   -1.937</td> <td> 0.053</td> <td>   -0.287</td> <td>    0.002</td>
</tr>
<tr>
  <th>C(Category)[T.HOUSE_AND_HOME]</th>      <td>   -0.2266</td> <td>    0.089</td> <td>   -2.552</td> <td> 0.011</td> <td>   -0.401</td> <td>   -0.053</td>
</tr>
<tr>
  <th>C(Category)[T.LIBRARIES_AND_DEMO]</th>  <td>   -0.2051</td> <td>    0.090</td> <td>   -2.288</td> <td> 0.022</td> <td>   -0.381</td> <td>   -0.029</td>
</tr>
<tr>
  <th>C(Category)[T.LIFESTYLE]</th>           <td>   -0.2767</td> <td>    0.073</td> <td>   -3.791</td> <td> 0.000</td> <td>   -0.420</td> <td>   -0.134</td>
</tr>
<tr>
  <th>C(Category)[T.MAPS_AND_NAVIGATION]</th> <td>   -0.3410</td> <td>    0.082</td> <td>   -4.167</td> <td> 0.000</td> <td>   -0.501</td> <td>   -0.181</td>
</tr>
<tr>
  <th>C(Category)[T.MEDICAL]</th>             <td>   -0.2042</td> <td>    0.072</td> <td>   -2.833</td> <td> 0.005</td> <td>   -0.345</td> <td>   -0.063</td>
</tr>
<tr>
  <th>C(Category)[T.NEWS_AND_MAGAZINES]</th>  <td>   -0.2850</td> <td>    0.075</td> <td>   -3.810</td> <td> 0.000</td> <td>   -0.432</td> <td>   -0.138</td>
</tr>
<tr>
  <th>C(Category)[T.PARENTING]</th>           <td>   -0.1066</td> <td>    0.097</td> <td>   -1.097</td> <td> 0.273</td> <td>   -0.297</td> <td>    0.084</td>
</tr>
<tr>
  <th>C(Category)[T.PERSONALIZATION]</th>     <td>   -0.1052</td> <td>    0.073</td> <td>   -1.443</td> <td> 0.149</td> <td>   -0.248</td> <td>    0.038</td>
</tr>
<tr>
  <th>C(Category)[T.PHOTOGRAPHY]</th>         <td>   -0.2251</td> <td>    0.074</td> <td>   -3.054</td> <td> 0.002</td> <td>   -0.370</td> <td>   -0.081</td>
</tr>
<tr>
  <th>C(Category)[T.PRODUCTIVITY]</th>        <td>   -0.2044</td> <td>    0.072</td> <td>   -2.820</td> <td> 0.005</td> <td>   -0.346</td> <td>   -0.062</td>
</tr>
<tr>
  <th>C(Category)[T.SHOPPING]</th>            <td>   -0.1446</td> <td>    0.075</td> <td>   -1.918</td> <td> 0.055</td> <td>   -0.292</td> <td>    0.003</td>
</tr>
<tr>
  <th>C(Category)[T.SOCIAL]</th>              <td>   -0.1287</td> <td>    0.075</td> <td>   -1.727</td> <td> 0.084</td> <td>   -0.275</td> <td>    0.017</td>
</tr>
<tr>
  <th>C(Category)[T.SPORTS]</th>              <td>   -0.1539</td> <td>    0.073</td> <td>   -2.109</td> <td> 0.035</td> <td>   -0.297</td> <td>   -0.011</td>
</tr>
<tr>
  <th>C(Category)[T.TOOLS]</th>               <td>   -0.3396</td> <td>    0.070</td> <td>   -4.847</td> <td> 0.000</td> <td>   -0.477</td> <td>   -0.202</td>
</tr>
<tr>
  <th>C(Category)[T.TRAVEL_AND_LOCAL]</th>    <td>   -0.2799</td> <td>    0.075</td> <td>   -3.708</td> <td> 0.000</td> <td>   -0.428</td> <td>   -0.132</td>
</tr>
<tr>
  <th>C(Category)[T.VIDEO_PLAYERS]</th>       <td>   -0.3233</td> <td>    0.079</td> <td>   -4.095</td> <td> 0.000</td> <td>   -0.478</td> <td>   -0.169</td>
</tr>
<tr>
  <th>C(Category)[T.WEATHER]</th>             <td>   -0.1662</td> <td>    0.090</td> <td>   -1.844</td> <td> 0.065</td> <td>   -0.343</td> <td>    0.010</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>4202.026</td> <th>  Durbin-Watson:     </th> <td>   1.387</td> 
</tr>
<tr>
  <th>Prob(Omnibus):</th>  <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>21757.980</td>
</tr>
<tr>
  <th>Skew:</th>           <td>-1.811</td>  <th>  Prob(JB):          </th> <td>    0.00</td> 
</tr>
<tr>
  <th>Kurtosis:</th>       <td> 8.925</td>  <th>  Cond. No.          </th> <td>    77.8</td> 
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



By looking the F-statistic and P valuse we can say rating is significantly diferent accross the category.



### Installation by category


```python
sns.catplot(x="Category",y="Installs",kind='violin',data=playstore, height=8, aspect=2/1);
sns.lineplot(x=range(0,len(playstore.Category.unique())),y=playstore["Installs"].mean(),)
plt.xticks(rotation=90);
```


![png](output_45_0.png)


By looking the above graph we can see that Education, Entertanments,Game ,Shopping,Social and weather are the most downlaod app. Where as Business , Events and medical are the least downloaded app.



```python
playstore.Genres.value_counts().head(30).plot("bar",figsize=(18,6))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f5ab5935c0>




![png](output_47_1.png)


By looking the above graph we found that Apps are well destributed among top 20 Genres


### Relationship Between rating and reviews


```python
sns.regplot(playstore.Rating,playstore.Reviews,color="g",x_estimator=np.mean);
```


![png](output_50_0.png)


We found that ratings and reviews have positive correlation

### App Reviews


```python
app_reviews= pd.read_csv(r"C:\Users\andee\googleplaystore_user_reviews.csv")


```


```python
app_reviews.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>App</th>
      <th>Translated_Review</th>
      <th>Sentiment</th>
      <th>Sentiment_Polarity</th>
      <th>Sentiment_Subjectivity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10 Best Foods for You</td>
      <td>I like eat delicious food. That's I'm cooking ...</td>
      <td>Positive</td>
      <td>1.00</td>
      <td>0.533333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10 Best Foods for You</td>
      <td>This help eating healthy exercise regular basis</td>
      <td>Positive</td>
      <td>0.25</td>
      <td>0.288462</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10 Best Foods for You</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10 Best Foods for You</td>
      <td>Works great especially going grocery store</td>
      <td>Positive</td>
      <td>0.40</td>
      <td>0.875000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10 Best Foods for You</td>
      <td>Best idea us</td>
      <td>Positive</td>
      <td>1.00</td>
      <td>0.300000</td>
    </tr>
  </tbody>
</table>
</div>




```python
app_reviews.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 64295 entries, 0 to 64294
    Data columns (total 5 columns):
    App                       64295 non-null object
    Translated_Review         37427 non-null object
    Sentiment                 37432 non-null object
    Sentiment_Polarity        37432 non-null float64
    Sentiment_Subjectivity    37432 non-null float64
    dtypes: float64(2), object(3)
    memory usage: 2.5+ MB
    


```python
#There a lot of null values across all the columns. Lets remove them

app_reviews.isnull().sum().sort_values()
```




    App                           0
    Sentiment                 26863
    Sentiment_Polarity        26863
    Sentiment_Subjectivity    26863
    Translated_Review         26868
    dtype: int64




```python
app_reviews.dropna(inplace=True)
app_reviews.isnull().sum().sort_values()
```




    App                       0
    Translated_Review         0
    Sentiment                 0
    Sentiment_Polarity        0
    Sentiment_Subjectivity    0
    dtype: int64




```python
app_reviews.Sentiment.value_counts()
```




    Positive    23998
    Negative     8271
    Neutral      5158
    Name: Sentiment, dtype: int64



There are almost 3 time positive review than negative.

## Joining app data with app reviews¶



```python
combined_data= playstore[["App","Type","Category","Genres","Content_Rating"]].merge(app_reviews,how="inner",left_on="App",right_on="App")

```


```python
combined_data.head()                                                                
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>App</th>
      <th>Type</th>
      <th>Category</th>
      <th>Genres</th>
      <th>Content_Rating</th>
      <th>Translated_Review</th>
      <th>Sentiment</th>
      <th>Sentiment_Polarity</th>
      <th>Sentiment_Subjectivity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Coloring book moana</td>
      <td>Free</td>
      <td>ART_AND_DESIGN</td>
      <td>Art &amp; Design;Pretend Play</td>
      <td>Everyone</td>
      <td>A kid's excessive ads. The types ads allowed a...</td>
      <td>Negative</td>
      <td>-0.250</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Coloring book moana</td>
      <td>Free</td>
      <td>ART_AND_DESIGN</td>
      <td>Art &amp; Design;Pretend Play</td>
      <td>Everyone</td>
      <td>It bad &gt;:(</td>
      <td>Negative</td>
      <td>-0.725</td>
      <td>0.833333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Coloring book moana</td>
      <td>Free</td>
      <td>ART_AND_DESIGN</td>
      <td>Art &amp; Design;Pretend Play</td>
      <td>Everyone</td>
      <td>like</td>
      <td>Neutral</td>
      <td>0.000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Coloring book moana</td>
      <td>Free</td>
      <td>ART_AND_DESIGN</td>
      <td>Art &amp; Design;Pretend Play</td>
      <td>Everyone</td>
      <td>I love colors inspyering</td>
      <td>Positive</td>
      <td>0.500</td>
      <td>0.600000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Coloring book moana</td>
      <td>Free</td>
      <td>ART_AND_DESIGN</td>
      <td>Art &amp; Design;Pretend Play</td>
      <td>Everyone</td>
      <td>I hate</td>
      <td>Negative</td>
      <td>-0.800</td>
      <td>0.900000</td>
    </tr>
  </tbody>
</table>
</div>



## Free app Vs Paid app Reviews


### Lets start with comparing sentimets for paid and free apps



```python
temp_type=(combined_data.groupby(["Type","Sentiment"])["App"].count()/combined_data.groupby(
    ["Type"])["App"].count()).reset_index(level=[0,1])

greenBars= temp_type[temp_type.Sentiment=='Positive']["App"]
orangeBars = temp_type[temp_type.Sentiment=='Negative']["App"]
blueBars = temp_type[temp_type.Sentiment=='Neutral']["App"]
r= list(range(0,len(temp_type.Type.unique())))
```


```python
barWidth = 0.85
names = temp_type.Type.unique()
```


```python
# Create green Bars
plt.bar(r, greenBars, color='#b5ffb9', edgecolor='white', width=barWidth)
# Create orange Bars
plt.bar(r, orangeBars, bottom=greenBars, color='#f9bc86', edgecolor='white', width=barWidth)
# Create blue Bars
plt.bar(r, blueBars, bottom=[i+j for i,j in zip(greenBars, orangeBars)], color='#a3acff', edgecolor='white', width=barWidth)
# Custom x axis
plt.xticks(r, names,rotation=90)
plt.xlabel("group")
#plt.legend() 
# Show graphic
plt.show()
```


![png](output_67_0.png)


We found that
1. Paid apps have high number of positive reviews 80% and very less neutral reviews.

2. Free Apps have just about 60% of positive reviews with almost 10% of neutral reviews.


### lets check category wise for paid and free app separatly



```python
#Analysis of sentimats by category for paid apps
temp_cat_paid=(combined_data[combined_data.Type=="Paid"].groupby(["Category","Sentiment"])["App"].count()/combined_data[combined_data.Type=="Paid"].groupby(
    ["Category"])["App"].count()).reset_index(level=[0,1])

greenBars= temp_cat_paid[temp_cat_paid.Sentiment=='Positive']["App"]
orangeBars = temp_cat_paid[temp_cat_paid.Sentiment=='Negative']["App"]
blueBars = temp_cat_paid[temp_cat_paid.Sentiment=='Neutral']["App"]
plt.figure(figsize=(15,8))

r= list(range(0,len(temp_cat_paid.Category.unique())))

barWidth = 0.85
names = temp_cat_paid.Category.unique()
# Create green Bars
plt.bar(r, greenBars, color='#b5ffb9', edgecolor='white', width=barWidth)
# Create orange Bars
plt.bar(r, orangeBars, bottom=greenBars, color='#f9bc86', edgecolor='white', width=barWidth)
# Create blue Bars
plt.bar(r, blueBars, bottom=[i+j for i,j in zip(greenBars, orangeBars)], 
        color='#a3acff', edgecolor='white', width=barWidth)
plt.axhline(y=.75,color='r', linestyle='-')
# Custom x axis
plt.xticks(r, names,rotation=90)
plt.xlabel("group")
#plt.legend() 
# Show graphic
plt.show()
```


![png](output_70_0.png)


Findings:

    1- Most of the paid medial app have positive reviews.
    
    2- Most of the paid app category have about 80% positive reviews except Game.
    
    3- Game have below 60% positive reviews with almost 40% negative reviews.

### Analysis of sentimats by category for Free apps




```python
temp_cat_free=(combined_data[combined_data.Type=="Free"].groupby(["Category","Sentiment"])["App"].count()/combined_data[combined_data.Type=="Free"].groupby(
    ["Category"])["App"].count()).reset_index(level=[0,1])

greenBars= temp_cat_free[temp_cat_free.Sentiment=='Positive']["App"]
orangeBars = temp_cat_free[temp_cat_free.Sentiment=='Negative']["App"]
blueBars = temp_cat_free[temp_cat_free.Sentiment=='Neutral']["App"]

plt.figure(figsize=(15,8))

r= list(range(0,len(temp_cat_free.Category.unique())))

barWidth = 0.85
names = temp_cat_free.Category.unique()
# Create green Bars
plt.bar(r, greenBars, color='#b5ffb9', edgecolor='white', width=barWidth)
# Create orange Bars
plt.bar(r, orangeBars, bottom=greenBars, color='#f9bc86', edgecolor='white', width=barWidth)
# Create blue Bars
plt.bar(r, blueBars, bottom=[i+j for i,j in zip(greenBars, orangeBars)], 
        color='#a3acff', edgecolor='white', width=barWidth)
plt.axhline(y=.75,color='r', linestyle='-')
# Custom x axis
plt.xticks(r, names,rotation=90)
plt.xlabel("group")
#plt.legend() 
# Show graphic
plt.show()
```


![png](output_73_0.png)


Findings:
    
    1- Average positive reviews are about 63% as compare to 80% for paid app
    
    2- Free apps have high numbers of neutral reviews 
    
    3- Free apps are more distrubuted across category 
    
    4- Free comics are very popular, with having 90% positive reviews

## Sentimet Polarity

### Free vs Paid



```python
sns.catplot("Type","Sentiment_Polarity",data= combined_data,alpha=.3);
```


![png](output_77_0.png)


We found that:

    1- Most of the Paid apps have positive polarity
    
    2- Free apps have a lot of strong nagetive reviews

### Deep dive into free apps polarity




```python
sns.catplot("Category","Sentiment_Polarity",data= 
            combined_data[combined_data.Type=="Free"],alpha=.2,height=8,aspect=1.5);
plt.xticks(rotation=90);
```


![png](output_80_0.png)


Based on the above graph:

    Category having strong Negative reviews are:
    
    1- Game
    
    2- Family
    
    3- Dating
    
    4- Entertainment
    
    5- Traivels and Local


```python

```
